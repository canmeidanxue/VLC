package org.videolan.vlc.interfaces;

public interface IHistory {
    boolean isEmpty();
    void clearHistory();
}
